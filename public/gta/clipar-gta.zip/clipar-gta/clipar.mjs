#!/usr/bin/env node
// clipar-gta · acha os melhores momentos de uma live pelo chat e corta clipes verticais.
// Uso: node clipar.mjs vod <link> | live <canal> | checar | ajuda
import { modoLive } from "./src/aovivo.mjs";
import { checar } from "./src/checar.mjs";
import { cinza, lerOpcoes, lima, negrito, vermelho } from "./src/util.mjs";
import { modoVod } from "./src/vod.mjs";

const AJUDA = `
${negrito("clipar-gta")}  acha os melhores momentos de uma live pelo chat e corta clipes verticais

${negrito("Comandos")}
  node clipar.mjs ${lima("vod")} LINK        transmissão que já terminou (link twitch.tv/videos/...)
  node clipar.mjs ${lima("live")} CANAL      live acontecendo agora (grava e corta enquanto roda)
  node clipar.mjs ${lima("checar")}          confere o que está instalado

${negrito("Ajustes")} ${cinza("(coloque no fim do comando)")}
  --clipes 5          quantos clipes (no live, 0 = sem limite)
  --antes 20          segundos antes da explosão do chat
  --depois 10         segundos depois
  --intervalo 90      distância mínima entre dois clipes, em segundos
  --saida pasta       onde salvar
  --legenda           legenda automática queimada no vídeo (Whisper, roda no seu computador)
  --idioma pt         idioma da legenda (padrão: detecta sozinho)
  --modelo small      tamanho do modelo de legenda: base, small, medium, large-v3-turbo
  --legenda-pos cima  legenda no alto da tela (padrão: embaixo)
  --formato moldura   vídeo inteiro no meio com fundo desfocado (padrão: corte, preenche a tela)

${negrito("Só no vod")}
  --so-momentos       só mostra a lista, sem cortar
  --video arquivo.mp4 corta de um vídeo que você já baixou
  --chat chat.json    usa um chat já baixado (também lê o JSON do TwitchDownloader)
  --qualidade 720     qualidade máxima do vídeo baixado (padrão: a melhor)

${negrito("Só no live")}
  --sensibilidade 3   quantas vezes acima do normal conta como pico
  --minutos 60        para sozinho depois de N minutos
  --guardar-tudo      guarda a live inteira (padrão: só os últimos 15 min, para poupar disco)

${negrito("Exemplos")}
  node clipar.mjs vod https://www.twitch.tv/videos/1234567890
  node clipar.mjs vod https://www.twitch.tv/videos/1234567890 --clipes 10 --legenda
  node clipar.mjs live nomedocanal --legenda --idioma pt

${cinza("Clipe é do streamer: só use canais que permitem e coloque o crédito em todo post.")}
`;

async function principal() {
  const [comando, ...resto] = process.argv.slice(2);
  const { posicionais, op } = lerOpcoes(resto, ["legenda", "so-momentos", "guardar-tudo"]);
  switch ((comando || "").toLowerCase()) {
    case "vod":
      return modoVod(posicionais[0], op);
    case "live":
    case "aovivo":
    case "ao-vivo":
      return modoLive(posicionais[0], op);
    case "checar":
    case "check":
      return checar();
    default:
      console.log(AJUDA);
  }
}

principal().then(
  () => process.exit(0),
  (e) => {
    console.log("");
    if (e.amigavel) {
      console.log(vermelho(`  ${e.message}`));
      if (e.dica) console.log(cinza(`  ${e.dica}`));
    } else {
      console.log(vermelho(`  Algo deu errado: ${e.message}`));
      console.log(cinza("  Copie esta mensagem e o comando que você rodou e cole no Claude ou no ChatGPT para entender o que houve."));
      if (process.env.DEBUG) console.error(e);
    }
    console.log("");
    process.exit(1);
  }
);
