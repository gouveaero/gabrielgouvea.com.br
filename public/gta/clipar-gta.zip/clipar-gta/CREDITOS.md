# Créditos

O código desta ferramenta é original, escrito por Gabriel Gouvea (com ajuda do Claude Code), sob licença MIT.

Ela se apoia em ferramentas abertas, que você instala separadamente:

| ferramenta | para quê | licença |
|---|---|---|
| [FFmpeg](https://ffmpeg.org) | cortar, deixar vertical, desenhar a legenda | LGPL/GPL |
| [Streamlink](https://streamlink.github.io) | gravar a live (modo ao vivo) | BSD-2-Clause |
| [whisper.cpp](https://github.com/ggml-org/whisper.cpp) | legenda local | MIT |
| [OpenAI Whisper](https://github.com/openai/whisper) | legenda local (alternativa em Python) | MIT |
| [Node.js](https://nodejs.org) | roda a ferramenta | MIT |

O formato de chat do [TwitchDownloader](https://github.com/lay295/TwitchDownloader) (MIT) é aceito em `--chat`, para quem já usa essa ferramenta.

A ideia de achar clipes pelo volume do chat é um método conhecido entre clipadores. Esta versão conta pessoas diferentes
(e não mensagens), compara com a mediana do entorno, acha o segundo exato da explosão e funciona também ao vivo.

Sem vínculo com Twitch, Rockstar Games, Take-Two ou qualquer ferramenta listada. Os clipes pertencem aos streamers:
use só canais que permitem e dê o crédito.
