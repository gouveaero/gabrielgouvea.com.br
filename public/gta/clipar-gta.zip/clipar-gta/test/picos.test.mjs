// Testes com chat sintético: rode com  node --test
import assert from "node:assert/strict";
import test from "node:test";
import { agrupar, gerarAss, palavrasDaFrase } from "../src/legenda.mjs";
import { acharMomentos, normalizarPalavra, reacaoDominante } from "../src/picos.mjs";
import { lerOpcoes } from "../src/util.mjs";
import { idDoVideo, nomeDoCanal } from "../src/twitch.mjs";

// Chat de 1 hora: ~1 pessoa por segundo, com explosões em momentos conhecidos.
function chatFalso({ explosoes = [], duracao = 3600, semente = 7 } = {}) {
  let x = semente;
  const aleatorio = () => ((x = (x * 1103515245 + 12345) % 2 ** 31) / 2 ** 31);
  const msgs = [];
  for (let t = 0; t < duracao; t += 1) msgs.push({ t: t + aleatorio(), usuario: `u${Math.floor(aleatorio() * 400)}`, texto: "oi" });
  for (const { t, pessoas, palavra = "KEKW" } of explosoes) {
    for (let i = 0; i < pessoas; i++) msgs.push({ t: t + aleatorio() * 8, usuario: `fa${t}_${i}`, texto: `${palavra} ${palavra}` });
  }
  return msgs;
}

test("acha as explosões na ordem de tamanho", () => {
  const msgs = chatFalso({ explosoes: [{ t: 600, pessoas: 40 }, { t: 1800, pessoas: 90 }, { t: 3000, pessoas: 60, palavra: "kkkkk" }] });
  const { momentos } = acharMomentos(msgs, 3600, { clipes: 3 });
  assert.equal(momentos.length, 3);
  assert.ok(Math.abs(momentos[0].explosao - 1800) <= 10, `primeiro em ${momentos[0].explosao}`);
  assert.ok(Math.abs(momentos[1].explosao - 3000) <= 10);
  assert.ok(Math.abs(momentos[2].explosao - 600) <= 10);
  assert.equal(momentos[0].reacao.palavra, "KEKW");
  assert.equal(momentos[1].reacao.palavra, "KKKK");
  assert.ok(momentos[0].vezes > 5);
});

test("o clipe começa antes e termina depois da explosão", () => {
  const msgs = chatFalso({ explosoes: [{ t: 1200, pessoas: 80 }] });
  const { momentos } = acharMomentos(msgs, 3600, { clipes: 1, antes: 25, depois: 15 });
  const m = momentos[0];
  assert.equal(m.inicio, m.explosao - 25);
  assert.equal(m.fim, m.explosao + 15);
});

test("respeita a distância mínima entre clipes", () => {
  const msgs = chatFalso({ explosoes: [{ t: 1000, pessoas: 80 }, { t: 1040, pessoas: 70 }, { t: 2000, pessoas: 50 }] });
  const { momentos } = acharMomentos(msgs, 3600, { clipes: 3, intervalo: 90 });
  const tempos = momentos.map((m) => m.explosao).sort((a, b) => a - b);
  for (let i = 1; i < tempos.length; i++) assert.ok(tempos[i] - tempos[i - 1] >= 90);
});

test("uma pessoa fazendo spam não vira pico", () => {
  const msgs = chatFalso();
  for (let i = 0; i < 300; i++) msgs.push({ t: 1500 + i * 0.02, usuario: "spammer", texto: "SPAM" });
  const { momentos } = acharMomentos(msgs, 3600, { clipes: 5 });
  assert.ok(!momentos.some((m) => Math.abs(m.explosao - 1500) < 20));
});

test("chat parado não gera momento falso", () => {
  const msgs = chatFalso({ duracao: 1800 });
  const { momentos } = acharMomentos(msgs, 1800, { clipes: 5 });
  assert.equal(momentos.length, 0);
});

test("risadas viram uma palavra só", () => {
  assert.equal(normalizarPalavra("KKKKKKK"), "kkkk");
  assert.equal(normalizarPalavra("hahahah"), "haha");
  assert.equal(normalizarPalavra("LMAOOO"), "lmao");
  assert.equal(normalizarPalavra("de"), null);
  const r = reacaoDominante([
    { usuario: "a", texto: "KEKW" },
    { usuario: "b", texto: "KEKW KEKW" },
    { usuario: "c", texto: "kekw" },
    { usuario: "d", texto: "nossa" },
  ]);
  assert.equal(r.pessoas, 3);
});

test("legenda: blocos curtos e palavra ativa em destaque", () => {
  const palavras = ["ele", "caiu", "do", "prédio", "e", "saiu", "andando."].map((texto, i) => ({ texto, ini: i * 0.3, fim: i * 0.3 + 0.25 }));
  const grupos = agrupar(palavras);
  assert.ok(grupos.every((g) => g.length <= 3));
  const ass = gerarAss(grupos);
  assert.match(ass, /PlayResY: 1920/);
  assert.match(ass, /\\c&H64F5CD&\}ELE/);
});

test("lê links e opções", () => {
  assert.equal(idDoVideo("https://www.twitch.tv/videos/2924308181?t=1h"), "2924308181");
  assert.equal(nomeDoCanal("https://www.twitch.tv/XQC"), "xqc");
  assert.equal(nomeDoCanal("@kiwo"), "kiwo");
  const { posicionais, op } = lerOpcoes(["LINK", "--clipes", "8", "--legenda", "--antes=30"], ["legenda"]);
  assert.deepEqual(posicionais, ["LINK"]);
  assert.equal(op.clipes, "8");
  assert.equal(op.legenda, true);
  assert.equal(op.antes, "30");
});

test("legenda: frase esticada por silêncio fica presa ao fim", () => {
  const w = palavrasDaFrase(" Got it", 0, 23);
  assert.equal(w.length, 2);
  assert.ok(w[0].ini > 20, `começou em ${w[0].ini}`);
  assert.ok(Math.abs(w[1].fim - 23) < 0.01);
  const n = palavrasDaFrase(" We got it. You know you can", 22.5, 26.4);
  assert.equal(n.length, 7);
  assert.equal(n[0].ini, 22.5);
});
