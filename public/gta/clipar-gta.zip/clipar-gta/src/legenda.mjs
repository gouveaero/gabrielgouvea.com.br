// Legenda local com Whisper (nada sai do seu computador).
// Aceita o whisper.cpp ("whisper-cli") ou o Whisper da OpenAI em Python ("whisper").
import fs from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import os from "node:os";
import { acharPrograma, buscar, erro, MAC, pastaUsuario, rodar, WINDOWS } from "./util.mjs";

const MODELOS_CPP = ["tiny", "base", "small", "medium", "large-v3-turbo"];

export function acharWhisper() {
  const cpp = acharPrograma("whisper-cli") || acharPrograma("whisper-cpp");
  if (cpp) return { tipo: "cpp", caminho: cpp };
  const py = acharPrograma("whisper");
  if (py) return { tipo: "python", caminho: py };
  return null;
}

export function dicaWhisper() {
  if (MAC) return "Instale com: brew install whisper-cpp";
  if (WINDOWS) return "Baixe o whisper-bin-x64.zip em github.com/ggml-org/whisper.cpp/releases e coloque o whisper-cli.exe na pasta da ferramenta";
  return "Instale o whisper.cpp (github.com/ggml-org/whisper.cpp) ou: pip install openai-whisper";
}

// Acha (ou baixa uma vez) o modelo do whisper.cpp.
export async function modeloCpp(nome = "small", aoProgresso = () => {}) {
  if (fs.existsSync(nome)) return nome; // caminho direto para um .bin
  if (!MODELOS_CPP.includes(nome)) throw erro(`Modelo desconhecido: ${nome}`, `Use um destes: ${MODELOS_CPP.join(", ")}`);
  const arquivo = `ggml-${nome}.bin`;
  const pastas = [pastaUsuario("modelos"), path.join(os.homedir(), ".cache", "whisper-models"), path.join(os.homedir(), "models", "whisper")];
  for (const p of pastas) if (fs.existsSync(path.join(p, arquivo))) return path.join(p, arquivo);
  const destino = path.join(pastas[0], arquivo);
  fs.mkdirSync(pastas[0], { recursive: true });
  const r = await buscar(`https://huggingface.co/ggerganov/whisper.cpp/resolve/main/${arquivo}`, { timeoutMs: 30 * 60_000 }, 2);
  if (!r.ok) throw erro(`Não consegui baixar o modelo ${arquivo} (HTTP ${r.status}).`);
  const total = Number(r.headers.get("content-length")) || 0;
  let baixado = 0;
  const leitor = Readable.fromWeb(r.body);
  leitor.on("data", (c) => {
    baixado += c.length;
    if (total) aoProgresso(baixado / total, total);
  });
  await pipeline(leitor, fs.createWriteStream(destino + ".parcial"));
  fs.renameSync(destino + ".parcial", destino);
  return destino;
}

// Transcreve e devolve palavras com tempo: [{ texto, ini, fim }] em segundos.
export async function transcrever({ whisper, audio, idioma = "auto", modelo = "small", aoProgresso }) {
  const base = audio.replace(/\.wav$/, "");
  if (whisper.tipo === "cpp") {
    const m = await modeloCpp(modelo, aoProgresso);
    // Tempo por frase (estável mesmo com música de jogo por baixo); as palavras são
    // distribuídas dentro da frase. -mc 0 e -sns evitam frases repetidas inventadas.
    const r = await rodar(whisper.caminho, ["-m", m, "-f", audio, "-l", idioma, "-mc", "0", "-sns", "-oj", "-of", base, "-np"]);
    if (r.codigo !== 0) throw new Error("whisper falhou: " + r.erros.trim().split("\n").slice(-2).join(" | "));
    const j = JSON.parse(fs.readFileSync(base + ".json", "utf8"));
    fs.rmSync(base + ".json", { force: true });
    return (j.transcription || []).flatMap((s) => palavrasDaFrase(s.text, s.offsets.from / 1000, s.offsets.to / 1000));
  }
  const pasta = path.dirname(audio);
  const args = [audio, "--model", modelo, "--word_timestamps", "True", "--output_format", "json", "--output_dir", pasta, "--fp16", "False", "--verbose", "False"];
  if (idioma !== "auto") args.push("--language", idioma);
  const r = await rodar(whisper.caminho, args);
  if (r.codigo !== 0) throw new Error("whisper falhou: " + r.erros.trim().split("\n").pop());
  const j = JSON.parse(fs.readFileSync(base + ".json", "utf8"));
  fs.rmSync(base + ".json", { force: true });
  return (j.segments || []).flatMap((s) => (s.words || []).map((w) => ({ texto: w.word, ini: w.start, fim: w.end })));
}

// Reparte o tempo de uma frase entre as palavras, pelo tamanho de cada uma.
// Frase longa demais para o que foi dito (silêncio ou música antes da fala) fica
// presa ao fim, que é o tempo mais confiável.
export function palavrasDaFrase(texto, ini, fim) {
  const palavras = String(texto).replace(/\[[^\]]*\]|\([^)]*\)/g, " ").trim().split(/\s+/).filter(Boolean);
  if (!palavras.length || fim <= ini) return [];
  const maximo = palavras.length * 0.55 + 1;
  if (fim - ini > maximo) ini = fim - (palavras.length * 0.45 + 0.5);
  const pesos = palavras.map((p) => p.length + 2);
  const total = pesos.reduce((a, b) => a + b, 0);
  let t = ini;
  return palavras.map((p, i) => {
    const d = ((fim - ini) * pesos[i]) / total;
    const w = { texto: p, ini: t, fim: t + d };
    t += d;
    return w;
  });
}

// Junta palavras em blocos curtos, do jeito que se lê em reels.
export function agrupar(palavras, { maxPalavras = 3, maxLetras = 16 } = {}) {
  const limpas = [];
  for (const p of palavras) {
    let t = String(p.texto).replace(/\[[^\]]*\]|\([^)]*\)|[{}\\]/g, "").trim();
    if (!t) continue;
    if (/^[^\p{L}\p{N}]+$/u.test(t)) {
      if (limpas.length) limpas[limpas.length - 1].texto += t;
      continue;
    }
    limpas.push({ texto: t, ini: p.ini, fim: Math.max(p.fim, p.ini + 0.08) });
  }
  const grupos = [];
  let atual = [];
  const fecha = () => {
    if (atual.length) grupos.push(atual);
    atual = [];
  };
  for (const p of limpas) {
    const anterior = atual[atual.length - 1];
    const letras = atual.reduce((n, x) => n + x.texto.length + 1, 0) + p.texto.length;
    if (atual.length && (atual.length >= maxPalavras || letras > maxLetras || p.ini - anterior.fim > 0.5 || /[.!?,]$/.test(anterior.texto))) fecha();
    atual.push(p);
  }
  fecha();
  return grupos;
}

const tempoAss = (s) => {
  s = Math.max(0, s);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const seg = (s % 60).toFixed(2).padStart(5, "0");
  return `${h}:${String(m).padStart(2, "0")}:${seg}`;
};

// Gera o .ass: letras grandes, contorno grosso, palavra falada em verde-lima.
export function gerarAss(grupos, { posicao = "baixo", duracaoClipe = 30 } = {}) {
  const alinhamento = posicao === "cima" ? 8 : 2;
  const margem = posicao === "cima" ? 330 : 500;
  const linhas = [
    "[Script Info]",
    "ScriptType: v4.00+",
    "PlayResX: 1080",
    "PlayResY: 1920",
    "WrapStyle: 0",
    "ScaledBorderAndShadow: yes",
    "",
    "[V4+ Styles]",
    "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
    `Style: Clipe,Arial Black,80,&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,1,0,1,7,3,${alinhamento},70,70,${margem},1`,
    "",
    "[Events]",
    "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
  ];
  grupos.forEach((g, gi) => {
    const proximo = grupos[gi + 1];
    let fimGrupo = g[g.length - 1].fim + 0.25;
    if (proximo) fimGrupo = Math.min(fimGrupo, proximo[0].ini);
    fimGrupo = Math.min(Math.max(fimGrupo, g[0].ini + 0.4), duracaoClipe);
    g.forEach((p, pi) => {
      const ini = pi === 0 ? g[0].ini : p.ini;
      const fim = pi + 1 < g.length ? g[pi + 1].ini : fimGrupo;
      if (fim <= ini) return;
      const texto = g
        .map((w, wi) => {
          const t = w.texto.toUpperCase();
          return wi === pi ? `{\\c&H64F5CD&}${t}{\\c&HFFFFFF&}` : t;
        })
        .join(" ");
      const pop = pi === 0 ? "{\\fscx80\\fscy80\\t(0,90,\\fscx100\\fscy100)}" : "";
      linhas.push(`Dialogue: 0,${tempoAss(ini)},${tempoAss(fim)},Clipe,,0,0,0,,${pop}${texto}`);
    });
  });
  return linhas.join("\n") + "\n";
}

// .srt simples (para quem prefere legendar no CapCut ou o ffmpeg não tem libass).
export function gerarSrt(grupos) {
  const t = (s) => {
    const ms = Math.round(s * 1000);
    const h = Math.floor(ms / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    const ss = Math.floor((ms % 60000) / 1000);
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(ss).padStart(2, "0")},${String(ms % 1000).padStart(3, "0")}`;
  };
  return grupos.map((g, i) => `${i + 1}\n${t(g[0].ini)} --> ${t(g[g.length - 1].fim)}\n${g.map((w) => w.texto).join(" ")}\n`).join("\n");
}
