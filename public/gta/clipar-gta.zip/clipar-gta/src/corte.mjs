// Corta e deixa o clipe vertical (9:16) com o ffmpeg.
import fs from "node:fs";
import path from "node:path";
import { acharPrograma, erro, MAC, rodar, WINDOWS } from "./util.mjs";

let ffmpegInfo = null;

// Procura um ffmpeg. Para queimar legenda ele precisa do filtro "ass" (biblioteca libass);
// no Mac, o "ffmpeg" do Homebrew vem sem ela e o "ffmpeg-full" vem com.
export async function acharFfmpeg({ precisaLegenda = false } = {}) {
  if (!ffmpegInfo) {
    const candidatos = [];
    if (process.env.FFMPEG) candidatos.push(process.env.FFMPEG);
    const doPath = acharPrograma("ffmpeg");
    if (doPath) candidatos.push(doPath);
    if (MAC) candidatos.push("/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg", "/usr/local/opt/ffmpeg-full/bin/ffmpeg");
    const encontrados = [];
    for (const c of [...new Set(candidatos)]) {
      if (!fs.existsSync(c)) continue;
      const { codigo, saida } = await rodar(c, ["-hide_banner", "-filters"]).catch(() => ({ codigo: 1, saida: "" }));
      if (codigo !== 0) continue;
      const enc = await rodar(c, ["-hide_banner", "-encoders"]).catch(() => ({ saida: "" }));
      encontrados.push({
        caminho: c,
        legenda: /^\s*\S+\s+ass\s/m.test(saida),
        x264: /libx264/.test(enc.saida),
      });
    }
    ffmpegInfo = encontrados;
  }
  if (!ffmpegInfo.length) {
    throw erro("Não achei o ffmpeg.", WINDOWS ? "Instale com: winget install Gyan.FFmpeg  (depois feche e abra o terminal)" : "Instale com: brew install ffmpeg-full");
  }
  if (precisaLegenda) return ffmpegInfo.find((f) => f.legenda) || null;
  return ffmpegInfo.find((f) => f.legenda) || ffmpegInfo[0];
}

export function acharFfprobe(ffmpeg) {
  const vizinho = path.join(path.dirname(ffmpeg), WINDOWS ? "ffprobe.exe" : "ffprobe");
  return fs.existsSync(vizinho) ? vizinho : acharPrograma("ffprobe");
}

// Filtros de imagem para o vertical.
// corte: preenche a tela com o centro do vídeo (o jeito mais comum).
// moldura: mostra o quadro inteiro no meio, com o próprio vídeo desfocado atrás.
export function filtroVertical(formato, arquivoLegenda) {
  let f;
  if (formato === "moldura") {
    f =
      "[0:v]split=2[a][b];" +
      "[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,gblur=sigma=28,eq=brightness=-0.12:saturation=0.9[fundo];" +
      "[b]scale=1080:-2:flags=lanczos[frente];" +
      "[fundo][frente]overlay=0:(H-h)/2,setsar=1";
  } else {
    f = "[0:v]scale=1080:1920:force_original_aspect_ratio=increase:flags=lanczos,crop=1080:1920,setsar=1";
  }
  if (arquivoLegenda) f += `,ass=${arquivoLegenda}`;
  return f + "[v]";
}

// Gera o clipe final a partir de um arquivo de origem (pedaço baixado ou vídeo inteiro).
// O .ass da legenda precisa estar na mesma pasta do arquivo de saída (evita problema
// com caminhos do Windows dentro do filtro).
export async function renderizar({ ffmpeg, origem, inicio, duracao, saida, formato = "corte", legendaAss = null }) {
  const pasta = path.dirname(saida);
  const args = [
    "-hide_banner", "-loglevel", "error", "-y",
    "-ss", inicio.toFixed(3), "-i", origem, "-t", duracao.toFixed(3),
    "-filter_complex", filtroVertical(formato, legendaAss ? path.basename(legendaAss) : null),
    "-map", "[v]", "-map", "0:a:0?",
    "-c:v", ffmpeg.x264 ? "libx264" : "mpeg4", ...(ffmpeg.x264 ? ["-preset", "veryfast", "-crf", "20", "-profile:v", "high"] : ["-q:v", "3"]),
    "-pix_fmt", "yuv420p", "-r", "30",
    "-c:a", "aac", "-b:a", "160k", "-ar", "48000",
    "-movflags", "+faststart",
    path.basename(saida),
  ];
  const r = await rodar(ffmpeg.caminho, args, { cwd: pasta });
  if (r.codigo !== 0) throw new Error("ffmpeg falhou: " + r.erros.trim().split("\n").slice(-3).join(" | "));
}

// Extrai o áudio em 16 kHz mono para o Whisper.
export async function extrairAudio({ ffmpeg, origem, inicio, duracao, saida }) {
  const r = await rodar(ffmpeg.caminho, [
    "-hide_banner", "-loglevel", "error", "-y",
    "-ss", inicio.toFixed(3), "-i", origem, "-t", duracao.toFixed(3),
    "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", saida,
  ]);
  if (r.codigo !== 0) throw new Error("ffmpeg (áudio) falhou: " + r.erros.trim().split("\n").pop());
}

// Um quadro do clipe pronto, para conferir sem abrir o vídeo.
export async function capa({ ffmpeg, video, saida, segundo = 2 }) {
  await rodar(ffmpeg.caminho, ["-hide_banner", "-loglevel", "error", "-y", "-ss", String(segundo), "-i", video, "-frames:v", "1", "-q:v", "3", saida]);
}
