// Acha os momentos em que o chat explode.
//
// Ideia: conta quantas PESSOAS diferentes escrevem em cada fatia de tempo (10 s por padrão).
// Contar pessoas, e não mensagens, impede que um só espectador fazendo spam crie um pico falso.
// Cada fatia é comparada com a mediana dos ~5 minutos em volta: o que vale é estar
// "mais alto que o normal daquele trecho", não ser a hora mais movimentada da live.
import { mediana } from "./util.mjs";

// Palavras que não dizem nada sobre a reação do chat.
const VAZIAS = new Set(
  (
    "a o e é de da do que em um uma pra para com no na os as se não nao eu vc voce você ele ela isso esse essa ta tá to tô " +
    "the a an is it i you he she to of and in on that this was for be are my me so its it's im i'm just lol? " +
    "@"
  ).split(/\s+/)
);

// Normaliza variações de risada e reação para contar como uma coisa só.
export function normalizarPalavra(p) {
  let w = p.toLowerCase().replace(/[!?.,:;"'()]+/g, "");
  if (!w || w.length < 2) return null;
  if (/^k{3,}$/.test(w)) return "kkkk";
  if (/^(ha|ah|he|hu|rs){2,}h?$/.test(w)) return "haha";
  if (/^l+o+l+$/.test(w)) return "lol";
  if (/^lm+a+o+$/.test(w)) return "lmao";
  if (/^w+$/.test(w)) return "w";
  if (VAZIAS.has(w)) return null;
  if (w.startsWith("http")) return null;
  return w;
}

// Palavra que mais gente usou numa janela de mensagens, com a grafia mais comum.
export function reacaoDominante(msgs) {
  const porPalavra = new Map();
  for (const m of msgs) {
    const vistas = new Set();
    for (const bruta of String(m.texto || "").split(/\s+/)) {
      const n = normalizarPalavra(bruta);
      if (!n || vistas.has(n)) continue;
      vistas.add(n);
      let reg = porPalavra.get(n);
      if (!reg) porPalavra.set(n, (reg = { pessoas: new Set(), grafias: new Map() }));
      reg.pessoas.add(m.usuario || Math.random());
      const g = n === "kkkk" ? "KKKK" : bruta.replace(/[!?.,:;"'()]+/g, "");
      reg.grafias.set(g, (reg.grafias.get(g) || 0) + 1);
    }
  }
  let melhor = null;
  for (const [, reg] of porPalavra) {
    if (!melhor || reg.pessoas.size > melhor.pessoas.size) melhor = reg;
  }
  if (!melhor || melhor.pessoas.size < 3) return null;
  const grafia = [...melhor.grafias.entries()].sort((a, b) => b[1] - a[1])[0][0];
  return { palavra: grafia, pessoas: melhor.pessoas.size };
}

// Conta pessoas diferentes por fatia.
export function contarFatias(mensagens, duracao, fatia) {
  const n = Math.max(1, Math.ceil(duracao / fatia));
  const conjuntos = Array.from({ length: n }, () => new Set());
  const brutas = new Array(n).fill(0);
  for (const m of mensagens) {
    const i = Math.floor(m.t / fatia);
    if (i < 0 || i >= n) continue;
    conjuntos[i].add(m.usuario ?? `#${brutas[i]}`);
    brutas[i]++;
  }
  return { pessoas: conjuntos.map((s) => s.size), mensagens: brutas };
}

// Linha de base de cada fatia: mediana do entorno (sem a própria fatia e as vizinhas).
export function linhaDeBase(contagens, fatia, { entorno = 300, piso = 2, soPassado = false } = {}) {
  const raio = Math.max(3, Math.round(entorno / 2 / fatia));
  const base = new Array(contagens.length);
  for (let i = 0; i < contagens.length; i++) {
    const ini = soPassado ? Math.max(0, i - raio * 2) : Math.max(0, i - raio);
    const fim = soPassado ? i - 2 : Math.min(contagens.length - 1, i + raio);
    const viz = [];
    for (let j = ini; j <= fim; j++) if (Math.abs(j - i) > 1) viz.push(contagens[j]);
    base[i] = Math.max(piso, mediana(viz));
  }
  return base;
}

// Encontra o segundo em que a explosão começa, olhando mensagens por segundo
// numa janela em volta da fatia de pico.
export function inicioDaExplosao(mensagens, tFatia, fatia) {
  const ini = tFatia - fatia;
  const fim = tFatia + fatia;
  const porSegundo = new Map();
  for (const m of mensagens) {
    if (m.t < ini || m.t >= fim) continue;
    const s = Math.floor(m.t);
    porSegundo.set(s, (porSegundo.get(s) || 0) + 1);
  }
  const taxa = [];
  for (let s = Math.floor(ini); s < fim; s++) {
    const v = (porSegundo.get(s - 1) || 0) + (porSegundo.get(s) || 0) + (porSegundo.get(s + 1) || 0);
    taxa.push([s, v]);
  }
  const max = Math.max(0, ...taxa.map((x) => x[1]));
  if (!max) return tFatia;
  const achou = taxa.find(([, v]) => v >= max * 0.5);
  return achou ? achou[0] : tFatia;
}

// Escolhe os melhores momentos de um chat completo (modo VOD).
export function acharMomentos(
  mensagens,
  duracao,
  { fatia = 10, clipes = 5, antes = 20, depois = 10, intervalo = 90, minimoPessoas = 5, minimoVezes = 1.5 } = {}
) {
  mensagens = [...mensagens].sort((a, b) => a.t - b.t);
  const { pessoas, mensagens: brutas } = contarFatias(mensagens, duracao, fatia);
  const base = linhaDeBase(pessoas, fatia);
  const candidatos = pessoas
    .map((p, i) => ({ i, pessoas: p, base: base[i], vezes: p / base[i] }))
    .filter((c) => c.pessoas >= minimoPessoas && c.vezes >= minimoVezes)
    .sort((a, b) => b.vezes - a.vezes || b.pessoas - a.pessoas);

  const escolhidos = [];
  for (const c of candidatos) {
    if (escolhidos.length >= clipes) break;
    const t = c.i * fatia;
    if (escolhidos.some((e) => Math.abs(e.tFatia - t) < intervalo)) continue;
    escolhidos.push({ ...c, tFatia: t });
  }

  const momentos = escolhidos.map((c, k) => {
    const explosao = inicioDaExplosao(mensagens, c.tFatia, fatia);
    const janela = mensagens.filter((m) => m.t >= explosao - 2 && m.t < explosao + 15);
    return {
      posicao: k + 1,
      explosao,
      inicio: Math.max(0, explosao - antes),
      fim: Math.min(duracao, explosao + depois),
      pessoas: c.pessoas,
      mensagens: brutas[c.i],
      normal: c.base,
      vezes: c.vezes,
      reacao: reacaoDominante(janela),
    };
  });
  return { momentos, fatias: { fatia, pessoas, base } };
}

// ---------- gráficos ----------
// Os dois gráficos mostram "quantas vezes acima do normal" cada fatia ficou: numa live
// sempre lotada, a contagem bruta esconde os picos; a comparação com o normal mostra.
const BLOCOS = " ▁▂▃▄▅▆▇█";

export function vezesPorFatia(pessoas, base) {
  return pessoas.map((p, i) => (base[i] ? p / base[i] : 0));
}

function porColuna(valores, colunas) {
  const passo = valores.length / colunas;
  const saida = [];
  for (let c = 0; c < colunas; c++) {
    const a = Math.floor(c * passo);
    const b = Math.max(a + 1, Math.floor((c + 1) * passo));
    saida.push(Math.max(...valores.slice(a, b)));
  }
  return { saida, passo };
}

// Gráfico de uma linha para o terminal, com os picos escolhidos marcados abaixo.
export function graficoTerminal(vezes, fatia, momentos, largura = 72) {
  const colunas = Math.max(1, Math.min(largura, vezes.length));
  const { saida, passo } = porColuna(vezes, colunas);
  const max = Math.max(2, ...saida);
  const linha = saida.map((v) => BLOCOS[Math.max(0, Math.min(8, Math.round(((v - 0.5) / (max - 0.5)) * 8)))]).join("");
  const marcas = new Array(colunas).fill(" ");
  for (const m of momentos) {
    const c = Math.min(colunas - 1, Math.floor(m.explosao / fatia / passo));
    marcas[c] = String(m.posicao).slice(-1);
  }
  return { linha, marcas: marcas.join("") };
}

// Gráfico em SVG (abre no navegador; serve de print).
export function graficoSVG(vezes, fatia, momentos, { titulo = "", largura = 1200, altura = 380 } = {}) {
  const pad = { e: 64, d: 28, t: 56, b: 44 };
  const W = largura - pad.e - pad.d;
  const H = altura - pad.t - pad.b;
  const colunas = Math.min(vezes.length, Math.floor(W / 2));
  const { saida, passo } = porColuna(vezes, colunas);
  const max = Math.max(3, Math.ceil(Math.max(...saida)));
  const duracao = vezes.length * fatia;
  const x = (t) => pad.e + (t / duracao) * W;
  const y = (v) => pad.t + H - (Math.min(v, max) / max) * H;
  const larguraBarra = W / colunas;
  const destaque = new Set(momentos.map((m) => Math.min(colunas - 1, Math.floor(m.explosao / fatia / passo))));
  let barras = "";
  saida.forEach((v, c) => {
    if (v <= 0) return;
    const pico = destaque.has(c) || destaque.has(c - 1) || destaque.has(c + 1);
    barras += `<rect x="${(pad.e + c * larguraBarra).toFixed(1)}" y="${y(v).toFixed(1)}" width="${Math.max(1, larguraBarra - 0.6).toFixed(2)}" height="${(pad.t + H - y(v)).toFixed(1)}" fill="${pico ? "#CDF564" : "#46464E"}"/>`;
  });
  let grade = "";
  for (let v = 1; v <= max; v++) {
    grade += `<line x1="${pad.e}" x2="${pad.e + W}" y1="${y(v)}" y2="${y(v)}" stroke="${v === 1 ? "#8A8A90" : "#1F1F24"}" ${v === 1 ? 'stroke-dasharray="4 4"' : ""}/>`;
    grade += `<text x="${pad.e - 10}" y="${y(v) + 4}" text-anchor="end" font-size="12" fill="${v === 1 ? "#B0B0B6" : "#6A6A70"}">${v}×</text>`;
  }
  grade += `<text x="${pad.e + W}" y="${y(1) - 6}" text-anchor="end" font-size="11" fill="#8A8A90">normal</text>`;
  let rotulos = "";
  for (const m of momentos) {
    const cx = x(m.explosao);
    rotulos += `<circle cx="${cx}" cy="${pad.t - 20}" r="12" fill="#CDF564"/><text x="${cx}" y="${pad.t - 15.5}" text-anchor="middle" font-size="13" font-weight="700" fill="#0A0A0B">${m.posicao}</text>`;
  }
  const passoH = duracao > 4 * 3600 ? 3600 : duracao > 3600 ? 1800 : duracao > 1200 ? 600 : 60;
  let eixo = "";
  for (let t = 0; t <= duracao; t += passoH) {
    const h = Math.floor(t / 3600);
    const mm = String(Math.floor((t % 3600) / 60)).padStart(2, "0");
    eixo += `<text x="${x(t)}" y="${altura - 16}" text-anchor="middle" font-size="12" fill="#8A8A90">${h}:${mm}</text>`;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${largura} ${altura}" width="${largura}" height="${altura}" font-family="ui-monospace, Menlo, Consolas, monospace">
<rect width="100%" height="100%" fill="#0A0A0B"/>
<text x="${pad.e}" y="22" font-size="13" fill="#8A8A90">${escapar(titulo)}</text>
${grade}
<line x1="${pad.e}" x2="${pad.e + W}" y1="${pad.t + H}" y2="${pad.t + H}" stroke="#2A2A30"/>
${barras}
${rotulos}
${eixo}
</svg>`;
}

function escapar(t) {
  return String(t).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}
