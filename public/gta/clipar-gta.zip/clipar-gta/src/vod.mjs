// Modo VOD: transmissão que já terminou.
// 1) baixa o chat  2) acha os picos  3) baixa só os trechos  4) corta em 9:16.
import fs from "node:fs";
import path from "node:path";
import { fazerClipe, prepararCorte } from "./clipe.mjs";
import { acharMomentos, graficoSVG, graficoTerminal, vezesPorFatia } from "./picos.mjs";
import { baixarChat, baixarTrecho, idDoVideo, infoDoVideo, lerChatDeArquivo, lerSegmentos, playlistDoVideo } from "./twitch.mjs";
import { cinza, erro, hms, hmsArquivo, lima, negrito, nomeSeguro, numero, numeroBR, verde } from "./util.mjs";

export async function modoVod(entrada, op) {
  const cfg = {
    clipes: numero(op, "clipes", 5, { min: 1, max: 100 }),
    antes: numero(op, "antes", 20, { min: 0, max: 600 }),
    depois: numero(op, "depois", 10, { min: 1, max: 600 }),
    intervalo: numero(op, "intervalo", 90, { min: 0 }),
    fatia: numero(op, "fatia", 10, { min: 2, max: 120 }),
    minimoPessoas: numero(op, "minimo", 5, { min: 1 }),
  };

  // ---------- 1. chat ----------
  let info = null;
  let mensagens;
  if (op.chat) {
    const lido = lerChatDeArquivo(JSON.parse(fs.readFileSync(op.chat, "utf8")));
    mensagens = lido.mensagens;
    info = lido.video;
    if (entrada) info = { ...(info || {}), ...(await infoDoVideo(idDoVideo(entrada))) };
  } else {
    if (!entrada) throw erro("Faltou o link do vídeo.", "Exemplo: node clipar.mjs vod https://www.twitch.tv/videos/1234567890");
    info = await infoDoVideo(idDoVideo(entrada));
  }
  const duracao = info?.duracao || Math.ceil((mensagens?.[mensagens.length - 1]?.t || 0) + 60);
  const saida = path.resolve(op.saida || path.join("clipes", nomeSeguro(`${info?.canal || "video"}-${info?.id || "local"}`)));
  fs.mkdirSync(saida, { recursive: true });

  console.log("");
  console.log(negrito(`  ${info?.nome || info?.canal || "Vídeo"}`) + cinza(`  ·  ${hms(duracao)} de transmissão${info?.jogo ? "  ·  " + info.jogo : ""}`));
  if (info?.titulo) console.log(cinza(`  ${info.titulo.slice(0, 90)}`));
  console.log("");

  if (!mensagens) {
    const inicio = Date.now();
    mensagens = await baixarChat(info.id, duracao, (f, n) => {
      process.stdout.write(`\r  Baixando o chat: ${String(Math.floor(f * 100)).padStart(3)}%  ·  ${n.toLocaleString("pt-BR")} mensagens   `);
    });
    process.stdout.write("\n");
    console.log(cinza(`  pronto em ${Math.round((Date.now() - inicio) / 1000)} s`));
    fs.writeFileSync(path.join(saida, "chat.json"), JSON.stringify({ video: info, mensagens }));
  }
  if (!mensagens.length) throw erro("Esse vídeo não tem mensagens no chat.", "Escolha uma transmissão com chat ativo.");

  // ---------- 2. picos ----------
  const { momentos, fatias } = acharMomentos(mensagens, duracao, cfg);
  const pessoasUnicas = new Set(mensagens.map((m) => m.usuario)).size;
  console.log("");
  console.log(cinza(`  ${mensagens.length.toLocaleString("pt-BR")} mensagens de ${pessoasUnicas.toLocaleString("pt-BR")} pessoas em ${hms(duracao)}`));
  const vezes = vezesPorFatia(fatias.pessoas, fatias.base);
  const g = graficoTerminal(vezes, cfg.fatia, momentos);
  console.log("  " + cinza(g.linha));
  console.log("  " + lima(g.marcas));
  console.log("");
  if (!momentos.length) {
    throw erro("Não achei nenhum pico claro nesse chat.", "Tente um vídeo mais longo, com chat mais ativo, ou diminua --minimo.");
  }
  for (const m of momentos) console.log("  " + linhaMomento(m, cfg.fatia));
  console.log("");

  fs.writeFileSync(path.join(saida, "grafico.svg"), graficoSVG(vezes, cfg.fatia, momentos, { titulo: `${info?.nome || ""} · chat a cada ${cfg.fatia} s, comparado com o normal do trecho` }));
  const registro = {
    video: info,
    ajustes: cfg,
    mensagens: mensagens.length,
    pessoas: pessoasUnicas,
    momentos: momentos.map((m) => ({ ...m, link: info?.id ? `https://www.twitch.tv/videos/${info.id}?t=${tempoTwitch(m.inicio)}` : null })),
  };
  fs.writeFileSync(path.join(saida, "momentos.json"), JSON.stringify(registro, null, 2));

  if (op["so-momentos"]) {
    console.log(verde(`  Lista salva em ${path.relative(process.cwd(), saida) || "."}`) + cinza("  (momentos.json, grafico.svg)"));
    return registro;
  }

  // ---------- 3 e 4. trechos e cortes ----------
  const prep = await prepararCorte(op, info?.idioma);
  let segmentos = null;
  if (!op.video) {
    const variante = await playlistDoVideo(info.id, op.qualidade);
    segmentos = await lerSegmentos(variante.url);
    console.log(cinza(`  Vídeo em ${variante.altura}p${variante.fps ? Math.round(variante.fps) : ""}. Baixando só ${momentos.length} trechos de ~${cfg.antes + cfg.depois} s.`));
  } else if (!fs.existsSync(op.video)) {
    throw erro(`Não achei o arquivo ${op.video}`);
  }
  const deslocamento = numero(op, "deslocamento", 0);
  const tmp = path.join(saida, ".tmp");
  fs.mkdirSync(tmp, { recursive: true });

  for (const m of momentos) {
    const nome = `clipe-${String(m.posicao).padStart(2, "0")}_${hmsArquivo(m.inicio)}.mp4`;
    const destino = path.join(saida, nome);
    process.stdout.write(`  #${m.posicao}  baixando o trecho...`);
    let origem;
    let inicio;
    if (segmentos) {
      const { bytes, inicioDoArquivo } = await baixarTrecho(segmentos, m.inicio, m.fim);
      origem = path.join(tmp, `trecho-${m.posicao}.ts`);
      fs.writeFileSync(origem, bytes);
      inicio = m.inicio - inicioDoArquivo;
    } else {
      origem = path.resolve(op.video);
      inicio = m.inicio + deslocamento;
    }
    await fazerClipe(prep, {
      origem,
      inicio,
      duracao: m.fim - m.inicio,
      saida: destino,
      segundoCapa: m.explosao - m.inicio,
      aoEtapa: (e) => process.stdout.write(`\r  #${m.posicao}  ${e}...              `),
    });
    if (segmentos) fs.rmSync(origem, { force: true });
    m.arquivo = nome;
    process.stdout.write(`\r  ${verde("✂")} #${m.posicao}  ${nome}   \n`);
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  registro.momentos.forEach((r, i) => (r.arquivo = momentos[i].arquivo));
  fs.writeFileSync(path.join(saida, "momentos.json"), JSON.stringify(registro, null, 2));

  console.log("");
  console.log(verde(`  Pronto: ${momentos.length} ${momentos.length === 1 ? "clipe" : "clipes"} em ${path.relative(process.cwd(), saida) || "."}`));
  console.log(cinza(`  Antes de postar: confira se ${info?.nome || "o streamer"} permite clipes e coloque o crédito (@${info?.canal || "canal"}) na tela e na legenda.`));
  return registro;
}

export function linhaMomento(m, fatia) {
  const reacao = m.reacao ? cinza(`  "${m.reacao.palavra}" ×${m.reacao.pessoas}`) : "";
  return `${lima(("#" + m.posicao).padEnd(3))}  ${hms(m.explosao).padStart(8)}  ${String(m.pessoas).padStart(4)} pessoas em ${fatia} s  ${lima(numeroBR(m.vezes) + "× o normal")}${reacao}`;
}

function tempoTwitch(s) {
  s = Math.max(0, Math.floor(s));
  return `${Math.floor(s / 3600)}h${Math.floor((s % 3600) / 60)}m${s % 60}s`;
}
