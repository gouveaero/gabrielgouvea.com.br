// Modo ao vivo: grava a live desde o primeiro segundo, lê o chat sem conta e
// corta cada pico enquanto a transmissão ainda está rolando.
//
// A gravação é salva em pedaços de 10 s com a hora no nome. Assim o pico do chat
// (que tem hora) vira um trecho exato da gravação, mesmo se a internet travar ou
// a Twitch pular um intervalo comercial. Pedaços antigos são apagados para não
// lotar o disco (use --guardar-tudo para manter a live inteira).
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fazerClipe, prepararCorte } from "./clipe.mjs";
import { graficoSVG, inicioDaExplosao, linhaDeBase, reacaoDominante, vezesPorFatia } from "./picos.mjs";
import { nomeDoCanal, ouvirChat, statusDoCanal } from "./twitch.mjs";
import {
  acharPrograma, amarelo, cinza, dataArquivo, erro, horaLocal, lima, MAC, mediana, negrito, numero, numeroBR, verde, vermelho, WINDOWS,
} from "./util.mjs";

const BLOCOS = " ▁▂▃▄▅▆▇█";

export async function modoLive(entrada, op) {
  if (!entrada) throw erro("Faltou o canal.", "Exemplo: node clipar.mjs live nomedocanal");
  const canal = nomeDoCanal(entrada);
  const cfg = {
    antes: numero(op, "antes", 20, { min: 0, max: 300 }),
    depois: numero(op, "depois", 10, { min: 1, max: 300 }),
    intervalo: numero(op, "intervalo", 90, { min: 0 }),
    fatia: numero(op, "fatia", 10, { min: 2, max: 60 }),
    sensibilidade: numero(op, "sensibilidade", 3, { min: 1.2 }),
    minimoPessoas: numero(op, "minimo", 5, { min: 1 }),
    clipes: numero(op, "clipes", 0, { min: 0 }),
    minutos: numero(op, "minutos", 0, { min: 0 }),
    manter: numero(op, "manter", 15, { min: 2 }),
    guardarTudo: !!op["guardar-tudo"],
  };
  const streamlink = acharPrograma("streamlink");
  if (!streamlink) {
    throw erro(
      "O modo ao vivo precisa do Streamlink.",
      WINDOWS ? "Instale com: winget install Streamlink.Streamlink  (depois feche e abra o terminal)" : MAC ? "Instale com: brew install streamlink" : "Instale com: pipx install streamlink"
    );
  }
  const st = await statusDoCanal(canal);
  const prep = await prepararCorte(op, st.idioma);

  const saida = path.resolve(op.saida || path.join("clipes", `${canal}-ao-vivo-${dataArquivo()}`));
  const gravacao = path.join(saida, "gravacao");
  const tmp = path.join(saida, ".tmp");
  fs.mkdirSync(gravacao, { recursive: true });
  fs.mkdirSync(tmp, { recursive: true });

  console.log("");
  console.log(negrito(`  ${st.nome}`) + cinza(st.aoVivo ? `  ·  AO VIVO  ·  ${st.espectadores.toLocaleString("pt-BR")} assistindo${st.jogo ? "  ·  " + st.jogo : ""}` : "  ·  fora do ar"));
  if (st.titulo) console.log(cinza(`  ${st.titulo.slice(0, 90)}`));
  if (!st.aoVivo) console.log(amarelo("  Esperando o canal entrar ao vivo. Pode deixar rodando: a gravação começa sozinha."));
  console.log(cinza(`  Pico = ${numeroBR(cfg.sensibilidade)}× o normal dos últimos 5 min (e pelo menos ${cfg.minimoPessoas} pessoas). Ctrl+C encerra.`));
  console.log("");

  const T0 = Date.now();
  const mensagens = [];
  const logChat = fs.createWriteStream(path.join(saida, "chat-ao-vivo.jsonl"));
  const pararChat = ouvirChat(
    canal,
    (m) => {
      mensagens.push({ t: (m.quando - T0) / 1000, usuario: m.usuario, texto: m.texto });
      logChat.write(JSON.stringify(m) + "\n");
    },
    (aviso) => console.log(cinza(`  ${aviso}`))
  );

  // ---------- gravação: streamlink -> ffmpeg em pedaços de 10 s ----------
  const logGravacao = fs.createWriteStream(path.join(saida, "gravacao.log"));
  const sl = spawn(streamlink, [`https://www.twitch.tv/${canal}`, "best", "--stdout", "--twitch-low-latency", "--retry-streams", "15", "--retry-max", "0", "--loglevel", "warning"], { windowsHide: true });
  const ff = spawn(
    prep.ffmpeg.caminho,
    ["-hide_banner", "-loglevel", "error", "-i", "pipe:0", "-map", "0:v:0?", "-map", "0:a:0?", "-c", "copy", "-f", "segment", "-segment_time", "10", "-segment_format", "mpegts", "-strftime", "1", path.join("gravacao", "%Y%m%d-%H%M%S.ts")],
    { cwd: saida, windowsHide: true }
  );
  sl.stdout.pipe(ff.stdin);
  ff.stdin.on("error", () => {});
  sl.stderr.pipe(logGravacao);
  ff.stderr.on("data", (d) => logGravacao.write(d));

  const pedacos = () =>
    fs
      .readdirSync(gravacao)
      .filter((n) => /^\d{8}-\d{6}\.ts$/.test(n))
      .sort()
      .map((n, i, todos) => ({ arquivo: path.join(gravacao, n), inicio: horaDoNome(n), fim: i + 1 < todos.length ? horaDoNome(todos[i + 1]) : Date.now() }));

  // ---------- leitura do chat em fatias ----------
  const historico = []; // pessoas por fatia
  const picos = [];
  const fila = [];
  let gravandoDesde = null;
  let ultimoPico = -Infinity;
  let encerrando = false;
  let proximaFatia = 0;
  let cortando = Promise.resolve();
  let tiques = 0;

  const fecharFatia = (k) => {
    const ini = k * cfg.fatia;
    const fim = ini + cfg.fatia;
    const doTrecho = mensagens.filter((m) => m.t >= ini && m.t < fim);
    const pessoas = new Set(doTrecho.map((m) => m.usuario)).size;
    historico[k] = pessoas;
    const viz = historico.slice(Math.max(0, k - 30), Math.max(0, k - 1)).filter((v) => v !== undefined);
    const base = Math.max(2, mediana(viz));
    const vezes = pessoas / base;
    const aquecido = viz.length >= 6;
    mostrarStatus(k, pessoas, base, vezes, aquecido);
    if (!aquecido || !gravandoDesde) return;
    if (vezes < cfg.sensibilidade || pessoas < cfg.minimoPessoas) return;
    if (ini - ultimoPico < cfg.intervalo) return;
    if (cfg.clipes && picos.length >= cfg.clipes) return;
    const explosao = inicioDaExplosao(mensagens, ini, cfg.fatia);
    if (T0 + explosao * 1000 < gravandoDesde) return; // aconteceu antes de a gravação começar
    ultimoPico = explosao;
    const pico = {
      posicao: picos.length + 1,
      explosao,
      inicio: explosao - cfg.antes,
      fim: explosao + cfg.depois,
      pessoas,
      mensagens: doTrecho.length,
      normal: base,
      vezes,
      reacao: reacaoDominante(mensagens.filter((m) => m.t >= explosao - 2 && m.t < explosao + 15)),
      hora: horaLocal(T0 + explosao * 1000),
    };
    picos.push(pico);
    fila.push(pico);
    limparLinha();
    const reacao = pico.reacao ? cinza(`  "${pico.reacao.palavra}" ×${pico.reacao.pessoas}`) : "";
    console.log(`  ${lima("PICO #" + pico.posicao)}  ${pico.hora}  ${pessoas} pessoas em ${cfg.fatia} s  ${lima(numeroBR(vezes) + "× o normal")}${reacao}` + cinza(`  (corta em ${Math.ceil(cfg.depois + 6)} s)`));
  };

  const prontos = () => picos.filter((p) => p.arquivo).length;
  let linhaAberta = false;
  const limparLinha = () => {
    if (linhaAberta) process.stdout.write("\r\x1b[2K");
    linhaAberta = false;
  };
  const mostrarStatus = (k, pessoas, base, vezes, aquecido) => {
    const ultimos = historico.slice(-24).map((v) => v || 0);
    const max = Math.max(1, ...ultimos);
    const barra = ultimos.map((v) => BLOCOS[Math.round((v / max) * 8)]).join("");
    const estado = !gravandoDesde ? amarelo("aguardando a live") : !aquecido ? cinza("medindo o normal do chat") : `${numeroBR(vezes)}× o normal`;
    const texto = `  ${cinza(horaLocal())}  ${cinza(barra)}  ${String(pessoas).padStart(3)} pessoas/${cfg.fatia}s  ${aquecido ? cinza("normal " + numeroBR(base, 0)) + "  " : ""}${estado}  ${cinza(`· ${prontos()} ${prontos() === 1 ? "clipe" : "clipes"}`)}`;
    if (process.stdout.isTTY) {
      process.stdout.write("\r\x1b[2K" + texto);
      linhaAberta = true;
    } else if (k % 6 === 0) console.log(texto);
  };

  // ---------- cortes ----------
  const cortar = async (pico, agora = false) => {
    const a = T0 + pico.inicio * 1000;
    const b = T0 + pico.fim * 1000;
    const usados = pedacos().filter((p) => p.fim > a && p.inicio < b);
    if (!usados.length) {
      limparLinha();
      console.log(amarelo(`  ! pico #${pico.posicao}: a gravação não cobre esse momento, pulei`));
      return;
    }
    const origem = path.join(tmp, `pico-${pico.posicao}.ts`);
    fs.writeFileSync(origem, Buffer.concat(usados.map((p) => fs.readFileSync(p.arquivo))));
    const comeco = Math.max(a, usados[0].inicio);
    const fimReal = agora ? Math.min(b, usados[usados.length - 1].fim) : b;
    const nome = `clipe-${String(pico.posicao).padStart(2, "0")}_${pico.hora.replace(/:/g, "h").replace(/h(\d\d)$/, "m$1s")}.mp4`;
    try {
      await fazerClipe(prep, {
        origem,
        inicio: (comeco - usados[0].inicio) / 1000,
        duracao: Math.max(3, (fimReal - comeco) / 1000),
        saida: path.join(saida, nome),
        segundoCapa: (T0 + pico.explosao * 1000 - comeco) / 1000,
      });
      pico.arquivo = nome;
      limparLinha();
      console.log(`  ${verde("✂ CLIPE")} #${pico.posicao}  ${nome}`);
      salvar();
    } catch (e) {
      limparLinha();
      console.log(vermelho(`  ! pico #${pico.posicao}: ${e.message}`));
    } finally {
      fs.rmSync(origem, { force: true });
    }
  };

  const salvar = () => {
    fs.writeFileSync(
      path.join(saida, "momentos.json"),
      JSON.stringify({ canal: st.canal, nome: st.nome, comecou: new Date(T0).toISOString(), ajustes: cfg, momentos: picos }, null, 2)
    );
  };

  const relogio = setInterval(() => {
    const agora = Date.now();
    if (!gravandoDesde) {
      const p = pedacos();
      if (p.length) {
        gravandoDesde = p[0].inicio;
        limparLinha();
        console.log(`  ${vermelho("●")} gravando desde ${horaLocal(gravandoDesde)}`);
      }
    }
    while ((proximaFatia + 1) * cfg.fatia * 1000 + T0 <= agora) fecharFatia(proximaFatia++);
    while (fila.length && agora >= T0 + (fila[0].fim + 6) * 1000) {
      const pico = fila.shift();
      cortando = cortando.then(() => cortar(pico));
    }
    if (!cfg.guardarTudo && ++tiques % 60 === 0) {
      const limite = agora - cfg.manter * 60_000;
      const emUso = fila.map((p) => T0 + p.inicio * 1000);
      const menor = Math.min(limite, ...emUso);
      for (const p of pedacos()) if (p.fim < menor) fs.rmSync(p.arquivo, { force: true });
    }
  }, 1000);

  // ---------- fim ----------
  return await new Promise((resolve) => {
    const encerrar = async (motivo) => {
      if (encerrando) return;
      encerrando = true;
      clearInterval(relogio);
      limparLinha();
      console.log("");
      console.log(cinza(`  ${motivo}. Fechando a gravação...`));
      pararChat();
      sl.kill();
      await new Promise((r) => {
        const t = setTimeout(() => {
          ff.kill();
          r();
        }, 15_000);
        ff.on("close", () => {
          clearTimeout(t);
          r();
        });
        ff.stdin.end();
      });
      for (const pico of fila.splice(0)) cortando = cortando.then(() => cortar(pico, true));
      await cortando;
      logChat.end();
      salvar();
      const pessoas = historico.map((v) => v || 0);
      if (pessoas.length > 2) {
        fs.writeFileSync(path.join(saida, "grafico.svg"), graficoSVG(vezesPorFatia(pessoas, linhaDeBase(pessoas, cfg.fatia, { soPassado: true })), cfg.fatia, picos, { titulo: `${st.nome} · ao vivo · chat a cada ${cfg.fatia} s, comparado com o normal` }));
      }
      if (!cfg.guardarTudo) fs.rmSync(gravacao, { recursive: true, force: true });
      fs.rmSync(tmp, { recursive: true, force: true });
      console.log(verde(`  Pronto: ${prontos()} ${prontos() === 1 ? "clipe" : "clipes"} em ${path.relative(process.cwd(), saida) || "."}`));
      console.log(cinza(`  Antes de postar: confira se ${st.nome} permite clipes e coloque o crédito (@${st.canal}) na tela e na legenda.`));
      resolve({ saida, picos });
    };
    sl.on("close", (codigo) => encerrar(gravandoDesde ? "A live terminou" : `O Streamlink parou (código ${codigo}); veja gravacao.log`));
    process.once("SIGINT", () => encerrar("Você encerrou"));
    if (cfg.minutos) setTimeout(() => encerrar(`Passaram ${cfg.minutos} min`), cfg.minutos * 60_000);
  });
}

function horaDoNome(n) {
  const m = n.match(/^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})/);
  return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime();
}
