// Conversa com a Twitch sem conta e sem token: a mesma API pública que o site usa
// para mostrar o chat de um vídeo antigo, e o chat ao vivo em modo anônimo (IRC).
import tls from "node:tls";
import { buscar, emParalelo, erro, espera } from "./util.mjs";

const GQL = "https://gql.twitch.tv/gql";
const CLIENT_ID = "kimne78kx3ncx6brgo4mv6wki5h1ko"; // identificador público do site da Twitch
const NAVEGADOR = "Mozilla/5.0 (clipar-gta)";

async function gql(corpo) {
  const r = await buscar(GQL, {
    method: "POST",
    headers: { "Client-ID": CLIENT_ID, "Content-Type": "application/json", "User-Agent": NAVEGADOR },
    body: JSON.stringify(corpo),
  });
  const j = await r.json();
  return Array.isArray(j) ? j[0] : j;
}

// ---------- links ----------
export function idDoVideo(entrada) {
  const s = String(entrada).trim();
  const m = s.match(/videos\/(\d+)/) || s.match(/^v?(\d{6,})$/);
  if (!m) {
    throw erro(
      `Não reconheci o link do vídeo: ${s}`,
      "Use o link de uma transmissão passada, no formato https://www.twitch.tv/videos/1234567890"
    );
  }
  return m[1];
}

export function nomeDoCanal(entrada) {
  const s = String(entrada).trim();
  const m = s.match(/twitch\.tv\/([a-zA-Z0-9_]{2,25})/) || s.match(/^@?([a-zA-Z0-9_]{2,25})$/);
  if (!m || m[1] === "videos") throw erro(`Não reconheci o canal: ${s}`, "Use só o nome do canal, como em: live kiwo");
  return m[1].toLowerCase();
}

// ---------- vídeo (VOD) ----------
export async function infoDoVideo(id) {
  const j = await gql({
    query: `query{ video(id:"${id}"){ id title lengthSeconds createdAt language owner{ login displayName broadcastSettings{ language } } game{ name } } }`,
  });
  const v = j?.data?.video;
  if (!v) throw erro("A Twitch não encontrou esse vídeo.", "Confira o link. Vídeos antigos expiram e somem da Twitch.");
  return {
    id: v.id,
    titulo: v.title,
    duracao: v.lengthSeconds,
    criado: v.createdAt,
    canal: v.owner?.login,
    nome: v.owner?.displayName,
    jogo: v.game?.name || null,
    idioma: idiomaTwitch(v.language || v.owner?.broadcastSettings?.language),
  };
}

// "EN", "pt", "es-mx" -> código que o Whisper entende ("en", "pt", "es").
function idiomaTwitch(l) {
  const c = String(l || "").toLowerCase().split(/[-_]/)[0];
  return /^[a-z]{2}$/.test(c) && c !== "ot" ? c : null;
}

const HASH_COMENTARIOS = "b70a3591ff0f4e0313d126c6a1502d79a1c02baebb288227c582044aa76adf6a";

// A Twitch guarda o chat de um vídeo em blocos de poucos segundos. Pedir um tempo (offset)
// devolve o bloco que termina nele ou logo depois; o próximo bloco vem pedindo
// "último segundo + 1". (A paginação por cursor hoje exige verificação de navegador.)
async function blocoDeComentarios(id, offset) {
  let j = await gql({
    operationName: "VideoCommentsByOffsetOrCursor",
    variables: { videoID: id, contentOffsetSeconds: offset },
    extensions: { persistedQuery: { version: 1, sha256Hash: HASH_COMENTARIOS } },
  });
  let c = j?.data?.video?.comments;
  if (!c) {
    // Plano B: a mesma consulta escrita por extenso.
    j = await gql({
      query: `query{ video(id:"${id}"){ comments(contentOffsetSeconds:${offset}){ edges{ node{ id contentOffsetSeconds commenter{ login } message{ fragments{ text } } } } } } }`,
    });
    c = j?.data?.video?.comments;
  }
  if (!c) throw new Error("a Twitch não devolveu o chat: " + JSON.stringify(j?.errors || j).slice(0, 160));
  return (c.edges || []).map((e) => e.node).filter(Boolean);
}

// Baixa o chat inteiro de um VOD, em vários trechos ao mesmo tempo.
export async function baixarChat(id, duracao, aoProgresso = () => {}) {
  const trechos = Math.max(1, Math.min(32, Math.ceil(duracao / 600)));
  const passo = duracao / trechos;
  const vistos = new Set();
  const mensagens = [];
  const feito = new Array(trechos).fill(0);
  const avisar = () => aoProgresso(feito.reduce((a, b) => a + b, 0) / trechos, mensagens.length);
  await emParalelo([...Array(trechos).keys()], 16, async (k) => {
    const ini = k * passo;
    const fim = k === trechos - 1 ? Infinity : (k + 1) * passo;
    let offset = Math.floor(ini);
    for (let volta = 0; volta < 200_000; volta++) {
      const bloco = await blocoDeComentarios(id, offset);
      if (!bloco.length) break;
      let ultimo = -1;
      for (const n of bloco) {
        const t = n.contentOffsetSeconds;
        ultimo = Math.max(ultimo, t);
        if (t < ini || t >= fim || vistos.has(n.id)) continue;
        vistos.add(n.id);
        mensagens.push({
          t,
          usuario: n.commenter?.login || null,
          texto: (n.message?.fragments || []).map((f) => f.text).join(""),
        });
      }
      if (ultimo >= fim || ultimo < offset - 1) break; // passou do trecho ou chegou ao fim do vídeo
      offset = Math.max(offset + 1, Math.floor(ultimo) + 1);
      if (offset >= duracao + 5) break;
      feito[k] = Math.min(1, (offset - ini) / passo);
      if (volta % 10 === 0) avisar();
    }
    feito[k] = 1;
    avisar();
  });
  mensagens.sort((a, b) => a.t - b.t);
  return mensagens;
}

// Lê um chat já baixado: o nosso formato ou o JSON do TwitchDownloader.
export function lerChatDeArquivo(json) {
  if (Array.isArray(json?.mensagens)) return { video: json.video || null, mensagens: json.mensagens };
  if (Array.isArray(json?.comments)) {
    const mensagens = json.comments.map((c) => ({
      t: c.content_offset_seconds,
      usuario: c.commenter?.name || c.commenter?.display_name || null,
      texto: c.message?.body || "",
    }));
    const v = json.video || {};
    return {
      video: { id: v.id, titulo: v.title, duracao: v.length || v.end || null, canal: json.streamer?.login || json.streamer?.name },
      mensagens,
    };
  }
  throw erro("Não entendi esse arquivo de chat.", "Use o chat.json salvo por esta ferramenta ou um JSON do TwitchDownloader.");
}

// ---------- pedaços do vídeo ----------
export async function playlistDoVideo(id, qualidade = "melhor") {
  const j = await gql({
    query: `query{ videoPlaybackAccessToken(id:"${id}", params:{ platform:"web", playerBackend:"mediaplayer", playerType:"site" }){ value signature } }`,
  });
  const tok = j?.data?.videoPlaybackAccessToken;
  if (!tok) throw erro("A Twitch não liberou esse vídeo.", "Vídeo só para inscritos ou expirado. Escolha outra transmissão.");
  const q = new URLSearchParams({
    sig: tok.signature,
    token: tok.value,
    allow_source: "true",
    allow_audio_only: "true",
    player: "twitchweb",
    playlist_include_framerate: "true",
    p: String(Math.floor(Math.random() * 1e6)),
  });
  const r = await buscar(`https://usher.ttvnw.net/vod/${id}.m3u8?${q}`, { headers: { "User-Agent": NAVEGADOR } });
  if (r.status === 403) throw erro("Esse vídeo é só para inscritos.", "Escolha uma transmissão aberta ao público.");
  if (!r.ok) throw erro(`A Twitch recusou o vídeo (HTTP ${r.status}).`, "Tente de novo em alguns minutos ou escolha outra transmissão.");
  const mestre = await r.text();
  const opcoes = [];
  const linhas = mestre.split(/\r?\n/);
  for (let i = 0; i < linhas.length; i++) {
    if (!linhas[i].startsWith("#EXT-X-STREAM-INF")) continue;
    const res = linhas[i].match(/RESOLUTION=(\d+)x(\d+)/);
    const fps = linhas[i].match(/FRAME-RATE=([\d.]+)/);
    const grupo = linhas[i].match(/VIDEO="([^"]+)"/);
    opcoes.push({
      url: linhas[i + 1],
      altura: res ? Number(res[2]) : 0,
      fps: fps ? Number(fps[1]) : 0,
      nome: grupo ? grupo[1] : "",
    });
  }
  const comVideo = opcoes.filter((o) => o.altura > 0).sort((a, b) => b.altura - a.altura || b.fps - a.fps);
  if (!comVideo.length) throw erro("Não achei nenhuma qualidade de vídeo para esse VOD.");
  let escolha = comVideo[0];
  if (qualidade && qualidade !== "melhor") {
    const alvo = Number(String(qualidade).replace(/p.*/, ""));
    escolha = comVideo.find((o) => o.altura <= alvo) || comVideo[comVideo.length - 1];
  }
  return escolha;
}

export async function lerSegmentos(urlPlaylist) {
  const r = await buscar(urlPlaylist, { headers: { "User-Agent": NAVEGADOR } });
  const texto = await r.text();
  const baseUrl = urlPlaylist.slice(0, urlPlaylist.lastIndexOf("/") + 1);
  const segmentos = [];
  let t = 0;
  let dur = null;
  for (const linha of texto.split(/\r?\n/)) {
    if (linha.startsWith("#EXTINF:")) dur = parseFloat(linha.slice(8));
    else if (linha && !linha.startsWith("#") && dur !== null) {
      segmentos.push({ inicio: t, duracao: dur, url: new URL(linha, baseUrl).toString() });
      t += dur;
      dur = null;
    }
  }
  return segmentos;
}

// Baixa só os segmentos que cobrem [inicio, fim] e devolve os bytes juntos (MPEG-TS emenda direto).
export async function baixarTrecho(segmentos, inicio, fim) {
  const precisa = segmentos.filter((s) => s.inicio + s.duracao > inicio && s.inicio < fim);
  if (!precisa.length) throw new Error("trecho fora do vídeo");
  const partes = await emParalelo(precisa, 6, async (s) => {
    let r = await buscar(s.url, { headers: { "User-Agent": NAVEGADOR } });
    if (r.status === 403 && /-unmuted\.ts/.test(s.url)) {
      // Trecho que a Twitch silenciou por música: o arquivo existe com outro nome.
      r = await buscar(s.url.replace("-unmuted.ts", "-muted.ts"), { headers: { "User-Agent": NAVEGADOR } });
    }
    if (!r.ok) throw new Error(`segmento HTTP ${r.status}`);
    return Buffer.from(await r.arrayBuffer());
  });
  return { bytes: Buffer.concat(partes), inicioDoArquivo: precisa[0].inicio };
}

// ---------- ao vivo ----------
export async function statusDoCanal(canal) {
  const j = await gql({
    query: `query{ user(login:"${canal}"){ login displayName broadcastSettings{ language } stream{ id title createdAt language game{ name } viewersCount } } }`,
  });
  const u = j?.data?.user;
  if (!u) throw erro(`O canal "${canal}" não existe na Twitch.`, "Confira o nome do canal.");
  return {
    canal: u.login,
    nome: u.displayName,
    aoVivo: !!u.stream,
    titulo: u.stream?.title || null,
    jogo: u.stream?.game?.name || null,
    espectadores: u.stream?.viewersCount || 0,
    inicio: u.stream?.createdAt || null,
    idioma: idiomaTwitch(u.stream?.language || u.broadcastSettings?.language),
  };
}

// Lê o chat ao vivo em modo anônimo (sem conta). Reconecta sozinho se cair.
export function ouvirChat(canal, aoReceber, aoAviso = () => {}) {
  let parar = false;
  let sock = null;
  let tentativas = 0;

  const conectar = () => {
    if (parar) return;
    const apelido = "justinfan" + Math.floor(10000 + Math.random() * 80000);
    sock = tls.connect(6697, "irc.chat.twitch.tv", { servername: "irc.chat.twitch.tv" });
    let resto = "";
    sock.setEncoding("utf8");
    sock.on("secureConnect", () => {
      tentativas = 0;
      sock.write(`CAP REQ :twitch.tv/tags\r\nPASS SCHMOOPIIE\r\nNICK ${apelido}\r\nJOIN #${canal}\r\n`);
    });
    sock.on("data", (d) => {
      resto += d;
      const linhas = resto.split("\r\n");
      resto = linhas.pop();
      for (const linha of linhas) {
        if (linha.startsWith("PING")) {
          sock.write("PONG :tmi.twitch.tv\r\n");
          continue;
        }
        const m = linha.match(/^(?:@(\S+) )?:([^!\s]+)![^\s]+ PRIVMSG #\S+ :(.*)$/);
        if (m) aoReceber({ quando: Date.now(), usuario: m[2], texto: m[3] });
      }
    });
    const reconectar = () => {
      if (parar) return;
      tentativas++;
      aoAviso(`chat desconectou, reconectando (${tentativas})`);
      setTimeout(conectar, Math.min(30_000, 1000 * 2 ** tentativas));
    };
    sock.on("error", () => {});
    sock.on("close", reconectar);
  };
  conectar();
  return () => {
    parar = true;
    sock?.destroy();
  };
}

export { espera };
