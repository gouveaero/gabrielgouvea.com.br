// Monta um clipe pronto: (legenda opcional) + vertical + capa.
import fs from "node:fs";
import path from "node:path";
import { acharFfmpeg, capa, extrairAudio, renderizar } from "./corte.mjs";
import { acharWhisper, agrupar, dicaWhisper, gerarAss, gerarSrt, transcrever } from "./legenda.mjs";
import { amarelo, cinza, erro } from "./util.mjs";

// Prepara o que o corte precisa, uma vez por execução.
// idiomaCanal: o idioma que o streamer declara na Twitch; vale quando não há --idioma.
// (Detectar sozinho num trecho de 30 s com música de jogo às vezes erra o idioma.)
export async function prepararCorte(op, idiomaCanal = null) {
  const querLegenda = !!op.legenda;
  let ffmpeg = await acharFfmpeg();
  let whisper = null;
  let queimar = false;
  if (querLegenda) {
    whisper = acharWhisper();
    if (!whisper) throw erro("Você pediu --legenda, mas não achei o Whisper.", dicaWhisper());
    const comLibass = await acharFfmpeg({ precisaLegenda: true });
    if (comLibass) {
      ffmpeg = comLibass;
      queimar = true;
    } else {
      console.log(
        amarelo("  ! Seu ffmpeg não sabe desenhar legenda (falta a libass).") +
          cinza(" Vou salvar a legenda em .srt ao lado de cada clipe. No Mac: brew install ffmpeg-full")
      );
    }
  }
  return {
    ffmpeg,
    whisper,
    queimar,
    formato: op.formato === "moldura" ? "moldura" : "corte",
    idioma: op.idioma || idiomaCanal || "auto",
    modelo: op.modelo || "small",
    posicao: op["legenda-pos"] === "cima" ? "cima" : "baixo",
  };
}

// origem: arquivo de vídeo; inicio/duracao em segundos dentro dele.
export async function fazerClipe(prep, { origem, inicio, duracao, saida, segundoCapa = 15, aoEtapa = () => {} }) {
  const pasta = path.dirname(saida);
  const nome = path.basename(saida, ".mp4");
  let ass = null;
  if (prep.whisper) {
    aoEtapa("legendando");
    const wav = path.join(pasta, `${nome}.wav`);
    await extrairAudio({ ffmpeg: prep.ffmpeg, origem, inicio, duracao, saida: wav });
    let ultimo = -1;
    const palavras = await transcrever({
      whisper: prep.whisper,
      audio: wav,
      idioma: prep.idioma,
      modelo: prep.modelo,
      aoProgresso: (f, total) => {
        const pct = Math.floor(f * 100);
        if (pct !== ultimo && pct % 10 === 0) {
          ultimo = pct;
          process.stdout.write(cinza(`\r  baixando o modelo de legenda (uma vez só, ${Math.round(total / 1e6)} MB): ${pct}%   `));
          if (pct === 100) process.stdout.write("\n");
        }
      },
    });
    fs.rmSync(wav, { force: true });
    const grupos = agrupar(palavras);
    if (grupos.length) {
      fs.writeFileSync(path.join(pasta, `${nome}.srt`), gerarSrt(grupos));
      if (prep.queimar) {
        ass = path.join(pasta, `${nome}.ass`);
        fs.writeFileSync(ass, gerarAss(grupos, { posicao: prep.posicao, duracaoClipe: duracao }));
      }
    }
  }
  aoEtapa("cortando");
  await renderizar({ ffmpeg: prep.ffmpeg, origem, inicio, duracao, saida, formato: prep.formato, legendaAss: ass });
  if (ass) fs.rmSync(ass, { force: true });
  await capa({ ffmpeg: prep.ffmpeg, video: saida, saida: path.join(pasta, `${nome}.jpg`), segundo: Math.max(0, Math.min(duracao - 1, segundoCapa)) }).catch(() => {});
  return saida;
}
