// Utilidades comuns: achar programas, rodar processos, formatar tempo, ler opções.
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const PASTA_FERRAMENTA = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export const WINDOWS = process.platform === "win32";
export const MAC = process.platform === "darwin";

// ---------- terminal ----------
const cor = process.stdout.isTTY && !process.env.NO_COLOR;
const pinta = (c) => (t) => (cor ? `\x1b[${c}m${t}\x1b[0m` : String(t));
export const verde = pinta("32");
export const amarelo = pinta("33");
export const vermelho = pinta("31");
export const cinza = pinta("90");
export const negrito = pinta("1");
export const lima = pinta("38;5;191");

export function erro(msg, dica) {
  const e = new Error(msg);
  e.dica = dica;
  e.amigavel = true;
  return e;
}

// ---------- tempo ----------
export function hms(seg) {
  seg = Math.max(0, Math.round(seg));
  const h = Math.floor(seg / 3600);
  const m = Math.floor((seg % 3600) / 60);
  const s = seg % 60;
  return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

// 1h02m10s, para nome de arquivo
export function hmsArquivo(seg) {
  seg = Math.max(0, Math.round(seg));
  const h = Math.floor(seg / 3600);
  const m = Math.floor((seg % 3600) / 60);
  const s = seg % 60;
  return `${h}h${String(m).padStart(2, "0")}m${String(s).padStart(2, "0")}s`;
}

export function horaLocal(ms = Date.now()) {
  const d = new Date(ms);
  return [d.getHours(), d.getMinutes(), d.getSeconds()].map((n) => String(n).padStart(2, "0")).join(":");
}

export function dataArquivo(ms = Date.now()) {
  const d = new Date(ms);
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
}

export const espera = (ms) => new Promise((r) => setTimeout(r, ms));

export function numeroBR(n, casas = 1) {
  return n.toFixed(casas).replace(".", ",");
}

// ---------- opções da linha de comando ----------
// Aceita "--opcao valor", "--opcao=valor" e chaves sem valor (--legenda).
export function lerOpcoes(argv, booleanas = []) {
  const posicionais = [];
  const op = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      let [k, v] = a.slice(2).split(/=(.*)/s, 2);
      if (v === undefined) {
        if (booleanas.includes(k)) v = true;
        else if (i + 1 < argv.length && !argv[i + 1].startsWith("--")) v = argv[++i];
        else v = true;
      }
      op[k] = v;
    } else posicionais.push(a);
  }
  return { posicionais, op };
}

export function numero(op, nome, padrao, { min = -Infinity, max = Infinity } = {}) {
  if (op[nome] === undefined) return padrao;
  const n = Number(String(op[nome]).replace(",", "."));
  if (!Number.isFinite(n) || n < min || n > max) {
    throw erro(`O valor de --${nome} precisa ser um número${min > -Infinity ? ` a partir de ${min}` : ""}.`, `Exemplo: --${nome} ${padrao}`);
  }
  return n;
}

// ---------- achar programas ----------
const cacheProgramas = new Map();

export function acharPrograma(nome, extras = []) {
  const chave = nome + "|" + extras.join("|");
  if (cacheProgramas.has(chave)) return cacheProgramas.get(chave);
  const exts = WINDOWS ? (process.env.PATHEXT || ".EXE;.CMD;.BAT").split(";").map((e) => e.toLowerCase()) : [""];
  const pastas = [
    ...extras,
    process.cwd(),
    PASTA_FERRAMENTA,
    path.join(PASTA_FERRAMENTA, "bin"),
    ...(process.env.PATH || "").split(path.delimiter),
  ];
  if (MAC) pastas.push("/opt/homebrew/bin", "/usr/local/bin");
  for (const pasta of pastas) {
    if (!pasta) continue;
    for (const ext of exts) {
      const p = path.join(pasta, nome + ext);
      try {
        const st = fs.statSync(p);
        if (st.isFile()) {
          if (!WINDOWS) fs.accessSync(p, fs.constants.X_OK);
          cacheProgramas.set(chave, p);
          return p;
        }
      } catch {}
    }
  }
  cacheProgramas.set(chave, null);
  return null;
}

// Roda um programa e devolve { codigo, saida, erros }. Nunca usa shell.
export function rodar(programa, args, { cwd, entrada, aoErro, aoSaida, timeoutMs } = {}) {
  return new Promise((resolve, reject) => {
    const p = spawn(programa, args, { cwd, windowsHide: true });
    let saida = "";
    let erros = "";
    let timer;
    if (timeoutMs) timer = setTimeout(() => p.kill("SIGKILL"), timeoutMs);
    p.stdout.on("data", (d) => {
      saida += d;
      aoSaida?.(d.toString());
    });
    p.stderr.on("data", (d) => {
      erros += d;
      if (erros.length > 200_000) erros = erros.slice(-100_000);
      aoErro?.(d.toString());
    });
    p.on("error", reject);
    p.on("close", (codigo) => {
      clearTimeout(timer);
      resolve({ codigo, saida, erros });
    });
    if (entrada !== undefined) p.stdin.end(entrada);
  });
}

// ---------- rede ----------
export async function buscar(url, opcoes = {}, tentativas = 4) {
  let ultimo;
  for (let i = 0; i < tentativas; i++) {
    try {
      const r = await fetch(url, { ...opcoes, signal: AbortSignal.timeout(opcoes.timeoutMs || 30_000) });
      if (r.status === 429 || r.status >= 500) throw new Error(`HTTP ${r.status}`);
      return r;
    } catch (e) {
      ultimo = e;
      await espera(800 * 2 ** i);
    }
  }
  throw ultimo;
}

// Roda tarefas com no máximo `limite` ao mesmo tempo.
export async function emParalelo(itens, limite, fn) {
  const resultados = new Array(itens.length);
  let proximo = 0;
  const trabalhadores = Array.from({ length: Math.min(limite, itens.length) }, async () => {
    while (proximo < itens.length) {
      const i = proximo++;
      resultados[i] = await fn(itens[i], i);
    }
  });
  await Promise.all(trabalhadores);
  return resultados;
}

export function pastaUsuario(...partes) {
  return path.join(os.homedir(), ".clipar-gta", ...partes);
}

export function nomeSeguro(t) {
  return String(t)
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-zA-Z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40) || "clipes";
}

export function mediana(valores) {
  if (!valores.length) return 0;
  const v = [...valores].sort((a, b) => a - b);
  const m = v.length >> 1;
  return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2;
}
