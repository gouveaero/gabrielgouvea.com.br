// Confere se tudo o que a ferramenta usa está instalado e diz como instalar o que falta.
import { acharFfmpeg } from "./corte.mjs";
import { acharWhisper, dicaWhisper } from "./legenda.mjs";
import { acharPrograma, amarelo, cinza, MAC, negrito, rodar, verde, vermelho, WINDOWS } from "./util.mjs";

const ok = (t) => console.log(`  ${verde("✓")} ${t}`);
const falta = (t, dica) => console.log(`  ${vermelho("✗")} ${t}\n      ${cinza(dica)}`);
const aviso = (t, dica) => console.log(`  ${amarelo("!")} ${t}\n      ${cinza(dica)}`);

export async function checar() {
  console.log("");
  console.log(negrito("  Conferindo o que a ferramenta precisa"));
  console.log("");
  let tudoCerto = true;

  const versao = Number(process.versions.node.split(".")[0]);
  if (versao >= 18) ok(`Node.js ${process.versions.node}`);
  else {
    tudoCerto = false;
    falta(`Node.js ${process.versions.node} é antigo`, "Instale a versão LTS em nodejs.org");
  }

  let ffmpeg = null;
  try {
    ffmpeg = await acharFfmpeg();
  } catch {}
  if (!ffmpeg) {
    tudoCerto = false;
    falta("ffmpeg (corta os clipes)", WINDOWS ? "winget install Gyan.FFmpeg" : MAC ? "brew install ffmpeg-full" : "sudo apt install ffmpeg");
  } else {
    const v = (await rodar(ffmpeg.caminho, ["-version"])).saida.split("\n")[0].replace(/ Copyright.*/, "");
    ok(`${v}  ${cinza(ffmpeg.caminho)}`);
    const comLegenda = await acharFfmpeg({ precisaLegenda: true });
    if (comLegenda) ok("ffmpeg desenha legenda (libass)");
    else aviso("ffmpeg sem libass: a legenda sai em .srt, não queimada no vídeo", MAC ? "brew install ffmpeg-full" : "use uma versão completa do ffmpeg (no Windows: winget install Gyan.FFmpeg)");
  }

  const sl = acharPrograma("streamlink");
  if (sl) {
    const v = (await rodar(sl, ["--version"])).saida.trim();
    ok(`${v}  ${cinza("(modo ao vivo)")}`);
  } else falta("Streamlink (só para o modo ao vivo)", WINDOWS ? "winget install Streamlink.Streamlink" : MAC ? "brew install streamlink" : "pipx install streamlink");

  const w = acharWhisper();
  if (w) ok(`Whisper ${w.tipo === "cpp" ? "(whisper.cpp)" : "(Python)"}  ${cinza("(legenda, opcional)")}`);
  else aviso("Whisper (só para --legenda, opcional)", dicaWhisper());

  try {
    const r = await fetch("https://gql.twitch.tv/gql", { method: "POST", headers: { "Client-ID": "kimne78kx3ncx6brgo4mv6wki5h1ko" }, body: '{"query":"query{ user(login:\\"twitch\\"){ id } }"}', signal: AbortSignal.timeout(10_000) });
    if (r.ok) ok("Internet e Twitch respondendo");
    else throw new Error(String(r.status));
  } catch (e) {
    tudoCerto = false;
    falta("Não consegui falar com a Twitch", "Confira a internet (rede de empresa ou escola às vezes bloqueia).");
  }

  console.log("");
  console.log(tudoCerto ? verde("  Tudo pronto. Comece com:  node clipar.mjs vod LINK-DO-VIDEO") : amarelo("  Instale o que falta, feche e abra o terminal, e rode de novo:  node clipar.mjs checar"));
  console.log("");
}
