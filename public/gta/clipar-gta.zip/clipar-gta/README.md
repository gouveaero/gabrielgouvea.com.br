# clipar-gta

Acha os melhores momentos de uma live da Twitch **pelo chat** e corta clipes verticais (9:16), prontos para Reels, TikTok e Shorts.

Quando acontece algo absurdo na live, o chat explode. A ferramenta conta quantas pessoas escrevem a cada 10 segundos, compara com o normal daquele trecho e corta o vídeo em volta de cada explosão. Você não precisa assistir 6 horas de live para achar 30 segundos bons.

Dois modos, um comando:

| modo | quando usar | o que faz |
|---|---|---|
| `vod` | a live já terminou | baixa o chat do vídeo, acha os picos e baixa **só** os trechos que importam |
| `live` | a live está no ar agora | grava desde o primeiro segundo, lê o chat sem conta e corta cada pico enquanto a live roda |

Legenda automática opcional, feita no seu computador com o Whisper (nada vai para a nuvem).

> Clipe é do streamer. Use só canais que permitem clipes (olhe os painéis do canal ou o Discord, ou participe de uma campanha de clipes oficial) e coloque o crédito na tela e na legenda. Nada aqui garante views ou dinheiro.

---

## 1. Instalar

Você precisa de um computador (Windows ou Mac). Não roda no celular. Tudo é gratuito.

### Windows

1. **Node.js**: baixe a versão **LTS** em [nodejs.org](https://nodejs.org) e instale clicando em *Next* até o fim.
2. Abra o **PowerShell** (tecla Windows, digite `PowerShell`, Enter) e rode, um de cada vez:
   ```
   winget install Gyan.FFmpeg
   winget install Streamlink.Streamlink
   ```
   Se perguntar sobre os termos, digite `Y` e Enter. O Streamlink só é necessário para o modo ao vivo.
3. **Legenda (opcional)**: em [github.com/ggml-org/whisper.cpp/releases](https://github.com/ggml-org/whisper.cpp/releases), abra a versão mais nova que tenha arquivos (*Assets*), baixe `whisper-bin-x64.zip`, descompacte e copie **tudo** que está dentro da pasta `Release` para uma pasta `bin` dentro da pasta da ferramenta.
4. **Feche e abra o PowerShell de novo** (o Windows só reconhece programas novos em janelas novas).

### Mac

1. Instale o Homebrew: cole no **Terminal** (Cmd + Espaço, digite `Terminal`, Enter) o comando que aparece em [brew.sh](https://brew.sh) e siga as instruções.
2. Depois rode:
   ```
   brew install node ffmpeg-full streamlink whisper-cpp
   ```
   `ffmpeg-full` é o ffmpeg que sabe desenhar legenda. `streamlink` é só para o modo ao vivo e `whisper-cpp` só para a legenda.

### Baixar a ferramenta

Baixe o ZIP deste repositório (botão verde **Code**, depois **Download ZIP**), descompacte na Área de Trabalho e renomeie a pasta para `clipar-gta`.

### Abrir o terminal dentro da pasta

- **Windows**: abra a pasta `clipar-gta`, clique na barra de endereço lá em cima, digite `powershell` e Enter.
- **Mac**: no Terminal, digite `cd ` (com espaço), arraste a pasta `clipar-gta` para dentro da janela e aperte Enter.

### Conferir

```
node clipar.mjs checar
```

Ele mostra o que está instalado e o comando para instalar o que falta.

---

## 2. Usar

### Live que já terminou (VOD)

Na página do streamer na Twitch, abra **Vídeos**, depois **Transmissões passadas**, e copie o link (fica assim: `https://www.twitch.tv/videos/1234567890`).

```
node clipar.mjs vod https://www.twitch.tv/videos/1234567890
```

Primeiro ele baixa o chat (de alguns segundos a poucos minutos, depende do tamanho da live), mostra o gráfico do chat e a lista dos 5 melhores momentos:

```
  #1  2:14:30   412 pessoas em 10 s  6,8× o normal  "KEKW" ×97
  #2  0:47:10   288 pessoas em 10 s  5,1× o normal  "OMEGALUL" ×40
```

Cada linha é um momento. A hora é quando o chat explodiu. "6,8× o normal" quer dizer que 6,8 vezes mais gente escreveu do que no normal daquele trecho. Depois ele baixa só uns 30 segundos em volta de cada momento e corta os clipes.

Só quer ver a lista antes de cortar? Coloque `--so-momentos` no fim.

### Live acontecendo agora

```
node clipar.mjs live nomedocanal --legenda
```

Pode rodar antes de a live começar: ele espera, começa a gravar no primeiro segundo e vai cortando cada pico enquanto a live acontece. No primeiro minuto ele só mede o normal do chat. Para encerrar, aperte **Ctrl + C**: ele corta o que ficou pendente e fecha tudo. Quando a live termina, ele encerra sozinho.

Para não lotar o disco, ele guarda só os últimos 15 minutos da gravação (os clipes ficam). Quer a live inteira? Use `--guardar-tudo`.

### O que sai

Tudo fica em `clipes/<canal>-...`:

```
clipe-01_2h14m10s.mp4    o clipe vertical 1080x1920
clipe-01_2h14m10s.jpg    um quadro do clipe, para conferir rápido
clipe-01_2h14m10s.srt    a legenda em texto (com --legenda)
momentos.json            a lista dos momentos, com o link do VOD no segundo certo
grafico.svg              o gráfico do chat (abra no navegador)
chat.json                o chat baixado (para rodar de novo sem baixar)
```

---

## 3. Ajustes

Coloque no fim do comando, por exemplo: `node clipar.mjs vod LINK --clipes 10 --antes 25`

| ajuste | o que faz | padrão |
|---|---|---|
| `--clipes 10` | quantos clipes (no live, 0 = sem limite) | 5 |
| `--antes 25` | segundos antes da explosão do chat | 20 |
| `--depois 15` | segundos depois | 10 |
| `--intervalo 120` | distância mínima entre dois clipes, em segundos | 90 |
| `--saida pasta` | onde salvar | `clipes/...` |
| `--legenda` | legenda queimada no vídeo, estilo reels | desligada |
| `--idioma pt` | idioma da legenda | detecta sozinho |
| `--modelo base` | modelo da legenda: `base` (rápido), `small`, `medium`, `large-v3-turbo` (melhor) | `small` |
| `--legenda-pos cima` | legenda no alto da tela | embaixo |
| `--formato moldura` | vídeo inteiro no meio, com fundo desfocado (mostra a câmera do streamer) | `corte` (preenche a tela) |
| `--minimo 8` | mínimo de pessoas para contar como pico | 5 |
| `--fatia 5` | tamanho de cada fatia de contagem, em segundos | 10 |

Só no `vod`: `--so-momentos`, `--video arquivo.mp4` (corta de um vídeo que você já tem), `--chat chat.json` (usa um chat já baixado; aceita também o JSON do TwitchDownloader), `--qualidade 720`.

Só no `live`: `--sensibilidade 2.5` (quantas vezes acima do normal conta como pico; padrão 3), `--minutos 60` (para sozinho), `--guardar-tudo`.

Por que a explosão e não o momento exato? O chat reage **depois**: a pessoa vê, entende e digita. Por isso o clipe começa 20 segundos antes da explosão. Clipe começando tarde? Aumente `--antes`. Muito tempo parado no começo? Diminua.

---

## 4. Problemas comuns

| aparece | faça isto |
|---|---|
| `node` ou `ffmpeg` não é reconhecido | feche o terminal e abra outro. Continuou? Instale de novo (passo 1). |
| `Cannot find module ... clipar.mjs` | o terminal não está na pasta da ferramenta. Refaça "Abrir o terminal dentro da pasta". |
| "Esse vídeo é só para inscritos" | VOD fechado para inscritos. Escolha outra transmissão. |
| "A Twitch não encontrou esse vídeo" | VODs expiram depois de alguns dias. Use uma live recente. |
| "Não achei nenhum pico claro" | live curta ou chat parado. Escolha uma live mais longa, com chat ativo. |
| "ffmpeg sem libass" | a legenda sai em `.srt` em vez de queimada. Mac: `brew install ffmpeg-full`. |
| no live, nenhum clipe | chat muito grande varia menos. Tente `--sensibilidade 2`. |
| legenda em cima da legenda do jogo | o GTA VI já mostra legenda nas cenas. Use `--legenda-pos cima` ou rode sem `--legenda`. |
| outro erro | copie a mensagem e o comando que você rodou e cole no Claude ou no ChatGPT. |

---

## 5. Com o Claude Code

A pasta também é uma **skill** do Claude Code (`SKILL.md`). Copie a pasta inteira para `~/.claude/skills/clipar-gta` (no Windows, `%USERPROFILE%\.claude\skills\clipar-gta`) e peça, por exemplo:

> assiste a live do canal X comigo e vai cortando os melhores momentos com legenda

O Claude roda o modo ao vivo em segundo plano, avisa a cada clipe e ajusta a sensibilidade se o chat estiver calmo ou agitado demais.

---

## Como funciona, em 4 passos

1. **Chat**: no VOD, baixa o chat pela mesma API pública que o site da Twitch usa para mostrar o replay do chat. Ao vivo, entra no chat como espectador anônimo (sem conta e sem token).
2. **Contagem**: conta **pessoas diferentes** a cada 10 s (alguém fazendo spam conta uma vez só) e compara cada fatia com a mediana dos 5 minutos em volta. Assim uma live sempre lotada não esconde os momentos de verdade.
3. **Explosão**: dentro da fatia vencedora, acha o segundo em que o chat dispara e marca a palavra que mais gente usou ("KEKW", "KKKK", "W").
4. **Corte**: no VOD, baixa só os pedaços do vídeo daquele trecho; ao vivo, grava em blocos de 10 s com a hora no nome e junta os blocos certos. O ffmpeg corta e deixa vertical.

Créditos e licenças em [CREDITOS.md](CREDITOS.md). Código sob licença MIT.
