---
name: clipar-gta
description: Assiste uma live da Twitch (ou um VOD) junto com o usuário, acha os melhores momentos pelo chat e corta clipes verticais 9:16 com legenda. Use quando o usuário pedir para clipar uma live, cortar os melhores momentos de uma stream, achar momentos virais num VOD da Twitch, "assiste a live comigo", "corta os clipes do GTA", "acha os picos do chat", ou passar um link twitch.tv/videos/... ou o nome de um canal pedindo clipes.
---

# clipar-gta

Ferramenta local (Node 18+, ffmpeg; Streamlink no modo ao vivo; Whisper opcional) que acha momentos pelo **chat**:
conta pessoas diferentes por fatia de 10 s, compara com a mediana dos ~5 min em volta e corta em volta de cada explosão.

A ferramenta está na mesma pasta deste arquivo. Rode tudo a partir dela:

```bash
cd "<pasta desta skill>"
node clipar.mjs checar
```

Se o `checar` apontar algo faltando, instale (ele mostra o comando para o sistema do usuário) e rode de novo.

## Antes de clipar

Clipe é do streamer. Confirme com o usuário (uma vez, sem sermão) que o canal permite clipes: painéis do canal,
Discord, ou campanha de clipes oficial. Lembre do crédito (@canal) na tela e na legenda do post.

## Live acontecendo agora

1. Rode em segundo plano (é um processo longo):
   ```bash
   node clipar.mjs live <canal> --legenda --idioma <pt|en>
   ```
   No Claude Code, use `run_in_background: true` e acompanhe a saída com o Monitor, filtrando as linhas
   `PICO`, `✂ CLIPE`, `●` (gravação começou), `!` (aviso) e `Pronto`.
2. A cada `✂ CLIPE`, avise o usuário em uma linha: hora, quantas vezes acima do normal, a palavra do chat e o
   arquivo (`<saida>/clipe-NN_....mp4`). O `.jpg` ao lado mostra um quadro do clipe: use-o para descrever o momento.
3. Ajuste pelo comportamento (reinicie o processo com o novo valor):
   - nenhum PICO em 15 min com chat ativo: `--sensibilidade 2` (chats enormes variam menos);
   - clipes demais ou fracos: `--sensibilidade 4` ou `--minimo 15`;
   - clipe começa depois da ação: `--antes 30`.
4. Para encerrar: interrompa o processo (Ctrl+C / matar a tarefa). Ele corta o pendente e fecha a gravação.

Sem `--guardar-tudo`, só os últimos 15 min da gravação ficam no disco.

## VOD (live que já terminou)

```bash
node clipar.mjs vod <link twitch.tv/videos/...> --so-momentos      # só a lista, rápido
node clipar.mjs vod <link> --clipes 8 --legenda --idioma pt          # corta
```

Mostre a lista ao usuário (hora, "× o normal", palavra do chat). Se ele quiser conferir um momento antes,
o `momentos.json` tem o link do VOD já no segundo certo. Para cortar de novo com outros ajustes sem baixar o chat:
`--chat <saida>/chat.json`.

## Ajustes úteis

`--clipes N` · `--antes S` (20) · `--depois S` (10) · `--intervalo S` (90) · `--saida pasta` ·
`--legenda` · `--idioma pt|en` · `--modelo base|small|medium|large-v3-turbo` · `--legenda-pos cima` ·
`--formato moldura` (quadro inteiro com fundo desfocado, mostra a câmera do streamer) · `--minutos N` (live).

## Depois dos clipes

Sugira ao usuário, para cada clipe: 1 frase de gancho para a tela no primeiro segundo, legenda do post com crédito
ao streamer e as hashtags do jogo. Postar o melhor primeiro (#1, maior "× o normal").

## Erros comuns

- "só para inscritos" ou "não encontrou esse vídeo": VOD fechado ou expirado, peça outro link.
- "ffmpeg sem libass": a legenda sai em `.srt`; no Mac, `brew install ffmpeg-full`.
- Jogo com legenda própria na tela (cenas do GTA VI): use `--legenda-pos cima` ou rode sem `--legenda`, para não empilhar duas legendas.
- `streamlink` ausente: só o modo ao vivo precisa; o `checar` mostra como instalar.
